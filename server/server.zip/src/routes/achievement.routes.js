import { Router } from 'express';

const router = Router();

// GET /api/v1/achievements
router.get('/', async (req, res) => {
  try {
    // Temporary diagnostic response.
    // Replace with database-backed achievements.
    return res.status(200).json({
      success: true,
      achievements: [],
      message: 'Achievements API is working',
    });
  } catch (error) {
    console.error('Achievements route error:', error);

    return res.status(500).json({
      success: false,
      message: 'Failed to fetch achievements',
    });
  }
});

export default router;